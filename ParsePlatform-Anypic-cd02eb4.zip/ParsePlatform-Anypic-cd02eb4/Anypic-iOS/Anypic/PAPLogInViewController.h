//
//  PAPLogInViewController.h
//  Anypic
//
//  Created by Mattieu Gamache-Asselin on 5/17/12.
//

@interface PAPLogInViewController : PFLogInViewController

@end
