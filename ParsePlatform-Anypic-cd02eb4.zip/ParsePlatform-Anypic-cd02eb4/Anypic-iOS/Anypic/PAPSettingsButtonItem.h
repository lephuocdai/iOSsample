//
//  PAPSettingsButtonItem.h
//  Anypic
//
//  Created by Héctor Ramos on 5/18/12.
//

@interface PAPSettingsButtonItem : UIBarButtonItem

- (id)initWithTarget:(id)target action:(SEL)action;

@end
