//
//  Copyright (c) 2013 Parse. All rights reserved.

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
